# Desnowing Project

## Trạng thái hoàn thiện
- Đã hoàn thiện mức 1
- Đã hoàn thiện mức 2

#### Testing
## Link Model 
Model train by SRS [gdrive](https://drive.google.com/file/d/1MDDwPH0_MNNWT4YoyGrCXxpvE9LGQ9VM/view?usp=sharing)

Model train by SNOW100K [gdrive](https://drive.google.com/file/d/14S4JtFlw7zV0k9m0ka3NTIxESMZp72He/view?usp=sharing)

## Link Dataset
[Dataset Link](https://studenthcmusedu-my.sharepoint.com/my?id=%2Fpersonal%2F24c11051%5Fstudent%5Fhcmus%5Fedu%5Fvn%2FDocuments%2FTri%20tu%E1%BB%87%20nh%C3%A2n%20t%E1%BA%A1o%2Fdataset&ga=1)

## Hướng dẫn chạy
1. Import desnowing.ipynb vào kaggle.
2. Upload dataset và pretrained model lên Kaggle.
3. Import dataset và pretrained model vào môi trường Kaggle trước khi chạy code.

---

*Lưu ý: Đảm bảo bạn đã thiết lập đúng đường dẫn tới dataset và pretrained-model trong code.*
